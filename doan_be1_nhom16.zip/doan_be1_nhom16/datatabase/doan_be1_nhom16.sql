-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Máy chủ: 127.0.0.1:3306
-- Thời gian đã tạo: Th6 18, 2021 lúc 09:56 AM
-- Phiên bản máy phục vụ: 5.7.31
-- Phiên bản PHP: 7.3.21

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Cơ sở dữ liệu: `doan_be1_nhom16`
--

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `tbl_admin`
--

DROP TABLE IF EXISTS `tbl_admin`;
CREATE TABLE IF NOT EXISTS `tbl_admin` (
  `adminId` int(11) NOT NULL AUTO_INCREMENT,
  `adminName` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `adminEmail` varchar(150) COLLATE utf8_unicode_ci NOT NULL,
  `adminUser` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `adminPass` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `level` int(30) NOT NULL,
  PRIMARY KEY (`adminId`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Đang đổ dữ liệu cho bảng `tbl_admin`
--

INSERT INTO `tbl_admin` (`adminId`, `adminName`, `adminEmail`, `adminUser`, `adminPass`, `level`) VALUES
(1, 'tanle', 'tanle@gmail.com', 'nguyentanle', 'e10adc3949ba59abbe56e057f20f883e', 0),
(2, 'admin', 'admin@gmail.com', 'admin', 'e10adc3949ba59abbe56e057f20f883e', 0),
(3, 'Nguyen Luan', 'nguyenluan@gmail.com', 'nguyenluan', 'e10adc3949ba59abbe56e057f20f883e', 0);

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `tbl_brand`
--

DROP TABLE IF EXISTS `tbl_brand`;
CREATE TABLE IF NOT EXISTS `tbl_brand` (
  `brandId` int(11) NOT NULL AUTO_INCREMENT,
  `brandName` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`brandId`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Đang đổ dữ liệu cho bảng `tbl_brand`
--

INSERT INTO `tbl_brand` (`brandId`, `brandName`) VALUES
(1, 'Samsung'),
(2, 'Apple'),
(3, 'Huawei'),
(4, 'Oppo'),
(5, 'Dell');

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `tbl_cart`
--

DROP TABLE IF EXISTS `tbl_cart`;
CREATE TABLE IF NOT EXISTS `tbl_cart` (
  `cartId` int(11) NOT NULL AUTO_INCREMENT,
  `productId` int(11) NOT NULL,
  `sId` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `productName` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `price` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `quantity` int(11) NOT NULL,
  `image` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`cartId`)
) ENGINE=InnoDB AUTO_INCREMENT=35 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Đang đổ dữ liệu cho bảng `tbl_cart`
--

INSERT INTO `tbl_cart` (`cartId`, `productId`, `sId`, `productName`, `price`, `quantity`, `image`) VALUES
(32, 7, 'g3uenk2qv6eruff42e5397aa6g', 'Samsung S10+', '12000000', 1, 'samsung-s10+.jpg');

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `tbl_category`
--

DROP TABLE IF EXISTS `tbl_category`;
CREATE TABLE IF NOT EXISTS `tbl_category` (
  `catId` int(11) NOT NULL AUTO_INCREMENT,
  `catName` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`catId`)
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Đang đổ dữ liệu cho bảng `tbl_category`
--

INSERT INTO `tbl_category` (`catId`, `catName`) VALUES
(1, 'Laptop'),
(2, 'Smart Watch'),
(3, 'Phone'),
(4, 'Tablet'),
(5, 'Head Phone');

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `tbl_compare`
--

DROP TABLE IF EXISTS `tbl_compare`;
CREATE TABLE IF NOT EXISTS `tbl_compare` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `customer_id` int(11) NOT NULL,
  `productId` int(11) NOT NULL,
  `productName` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `price` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `image` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Đang đổ dữ liệu cho bảng `tbl_compare`
--

INSERT INTO `tbl_compare` (`id`, `customer_id`, `productId`, `productName`, `price`, `image`) VALUES
(1, 3, 9, 'IPad Pro 11', '21900000', 'ipad-pro-11-inch-2020-xam-1020x680-org.jpg'),
(2, 3, 15, 'Laptop Apple MacBook Air 2017 i5', '19390000', 'apple-macbook-air-mqd32sa-a-i5-5350u-bac-1-org.jpg'),
(3, 8, 14, 'Samsung Galaxy Watch Active 2 44mm ', '4990000', 'samsung-galaxy-watch-active-2-44-mm-sillicon-den-2-org.jpg'),
(4, 8, 4, 'Samsung Galaxy Tab S7', '18990000', 'samsung-galaxy-tab-s7-xanh-duong-1-org.jpg');

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `tbl_customer`
--

DROP TABLE IF EXISTS `tbl_customer`;
CREATE TABLE IF NOT EXISTS `tbl_customer` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `address` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `city` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  `country` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  `zipcode` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  `phone` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `password` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Đang đổ dữ liệu cho bảng `tbl_customer`
--

INSERT INTO `tbl_customer` (`id`, `name`, `address`, `city`, `country`, `zipcode`, `phone`, `email`, `password`) VALUES
(3, 'Nguyen Tan Le', '117 Đình Phong Phú', 'TPHCM', 'hcm', '700000', '0335582894', 'nguyentanle@gmail.com', 'e10adc3949ba59abbe56e057f20f883e'),
(6, 'Nguyá»…n Táº¥n Lá»…', '117 dinh phong phu', 'Ho Chi Minh', 'hcm', '121324', '0213987123', 'tanle1389@gmail.com', 'e10adc3949ba59abbe56e057f20f883e'),
(7, 'Nguyá»…n Táº¥n Lá»…', '117 dinh phong phu', 'Ho Chi Minh', 'hcm', 'MH1234', '0213987123', 'tanle@gmail.com', 'e10adc3949ba59abbe56e057f20f883e'),
(8, 'Nguyen Luan', '117 dinh phong phu', 'Ho Chi Minh', 'hcm', '121324', '0213987123', 'luan@gmail..com', 'e10adc3949ba59abbe56e057f20f883e');

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `tbl_order`
--

DROP TABLE IF EXISTS `tbl_order`;
CREATE TABLE IF NOT EXISTS `tbl_order` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `productId` int(11) NOT NULL,
  `productName` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `customer_id` int(11) NOT NULL,
  `quantity` int(11) NOT NULL,
  `price` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `image` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `status` int(11) NOT NULL DEFAULT '0',
  `date_order` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=66 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Đang đổ dữ liệu cho bảng `tbl_order`
--

INSERT INTO `tbl_order` (`id`, `productId`, `productName`, `customer_id`, `quantity`, `price`, `image`, `status`, `date_order`) VALUES
(65, 1, 'Iphone 12 64GB', 8, 1, '19530000', 'iphone-12-violet-gc-org.jpg', 1, '2021-06-18 15:21:51');

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `tbl_product`
--

DROP TABLE IF EXISTS `tbl_product`;
CREATE TABLE IF NOT EXISTS `tbl_product` (
  `productId` int(11) NOT NULL AUTO_INCREMENT,
  `productName` varchar(500) COLLATE utf8_unicode_ci NOT NULL,
  `product_code` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `productQuantity` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `product_soldout` varchar(50) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  `product_remain` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `catId` int(11) NOT NULL,
  `brandId` int(11) NOT NULL,
  `product_desc` varchar(2000) COLLATE utf8_unicode_ci NOT NULL,
  `type` int(11) NOT NULL,
  `price` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `image` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`productId`)
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Đang đổ dữ liệu cho bảng `tbl_product`
--

INSERT INTO `tbl_product` (`productId`, `productName`, `product_code`, `productQuantity`, `product_soldout`, `product_remain`, `catId`, `brandId`, `product_desc`, `type`, `price`, `image`) VALUES
(1, 'Iphone 12 64GB', 'MH1121', '80', '0', '80', 3, 2, 'In the last months of 2020, Apple has officially introduced to users and iFan the new generation of iPhone 12 series with a series of breakthrough features, completely redesigned design, powerful performance and one of them. That is the iPhone 12 64GB.', 0, '19530000', 'iphone-12-violet-gc-org.jpg'),
(2, 'OPPO Reno5', 'MH1127', '80', '0', '80', 3, 4, 'OPPO Reno5 is an impressive combination of performance and design, giving users a phone that integrates many of OPPO\'s leading camera and battery technologies at a mid-range price point.', 0, '8690000', 'oppo-reno5-bac-1-org.jpg'),
(3, 'Laptop Dell Inspiron 3501 i7 ', 'MH1128', '60', '0', '60', 1, 5, 'Dell Inspiron 3501 i7 (70234075) is where you\'ll be with a stunning touch screen, powerful 11th Gen Intel processors, and premium compact design.', 1, '21990000', 'dell-inspiron-3501-i7-70234075-1-org.jpg'),
(4, 'Samsung Galaxy Tab S7', 'MH1124', '50', '0', '50', 4, 1, 'Samsung Galaxy Tab S7 tablet has a gorgeous design, super smooth 120 Hz screen, impressive dual camera, S Pen and powerful performance at the top of the Android tablet market.', 0, '18990000', 'samsung-galaxy-tab-s7-xanh-duong-1-org.jpg'),
(5, 'Laptop Apple MacBook Air M1 2020', 'MH1129', '70', '0', '70', 1, 2, 'The Apple Macbook Air M1 2020 (MGNA3SA/A) laptop with the first exclusive Apple M1 chip for computers brings an upgrade in configuration compared to the previous generation, besides the configuration, the design is also a Very valuable point of this product.', 0, '33590000', 'space-1-org.jpg'),
(6, 'Laptop Dell A503', 'MH1122', '50', '0', '50', 1, 5, 'Dell A503 laptop is equipped with the new 11th generation processor from Intel with a thin and light design, but it still offers a great gaming experience for young people.', 1, '10000000', 'lap-top-dell.jpg'),
(9, 'IPad Pro 11', 'MH1125', '100', '0', '100', 4, 2, 'iPad Pro 11-inch Wifi 128GB (2020) is an iPad model launched by Apple on March 18 with an almost unchanged design compared to the previous generation, mainly an upgrade from the A12Z chip for powerful performance and The camera cluster has a new sensor that supports augmented reality.', 0, '21900000', 'ipad-pro-11-inch-2020-xam-1020x680-org.jpg'),
(10, 'Apple Watch Series 4 GPS Aluminum Case With Sport Loop', 'MH1140', '65', '0', '65', 2, 2, 'Apple WatchSeries 4 GPS Aluminum Case With Sport Loop brings useful upgrades to support users in the most optimal way. Prominent among them is the improved S6 processor chip, the watchOS 7 operating system with many new features that promises to bring better and more interesting experiences.', 0, '9700000', 'apple-watch-s6-40mm-vien-nhom-day-cao-su-den-cont-1-org.jpg'),
(11, 'Head Phone Bluetooth AirPods Pro Wireless Charge Apple MWP22', 'MH1123', '60', '0', '60', 5, 2, 'AirPods Pro with a neat, beautiful and sophisticated design, the headset is designed in the form of In-ear instead of Earbuds like AirPods 2, allowing better noise cancellation, difficult to fall when worn and quieter.', 1, '5390000', 'airpods-pro-wireless-charge-apple-mwp22-ava-1-org.jpg'),
(12, 'Huawei MatePad T10s ', 'MH1127', '80', '0', '80', 4, 3, 'Huawei\'s tablet, Huawei MatePad T10s has also been officially launched. The 8-core processor opens up a world of smooth entertainment, vivid in every moment with the huge screen, revealing a good tablet in the price range that anyone will love.', 0, '5140000', 'huawei-matepad-t10s-1-org.jpg'),
(13, 'Head Phone Bluetooth True Wireless Samsung Galaxy Buds+ R175', 'MH1128', '30', '0', '30', 5, 1, 'True Wireless headphones with compact design, luxurious black color, glossy.', 0, '1490000', 'bluetooth-tws-samsung-galaxy-bud-r175-1-org.jpg'),
(14, 'Samsung Galaxy Watch Active 2 44mm ', 'MH1129', '50', '0', '50', 2, 1, 'The Samsung Galaxy Watch Active 2 smartwatch is more advanced with an anti-glare screen, displaying sharp information. Other utilities have also been upgraded to bring the most convenience to users.', 0, '4990000', 'samsung-galaxy-watch-active-2-44-mm-sillicon-den-2-org.jpg'),
(15, 'Laptop Apple MacBook Air 2017 i5', 'MH1125', '70', '0', '70', 1, 2, 'MacBook Air 2017 i5 128GB is an office laptop model, with an ultra-thin and light design, luxurious aluminum unibody. The machine has stable performance, extremely long battery life of 12 hours, suitable for most work and entertainment needs.', 0, '19390000', 'apple-macbook-air-mqd32sa-a-i5-5350u-bac-1-org.jpg');

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `tbl_slider`
--

DROP TABLE IF EXISTS `tbl_slider`;
CREATE TABLE IF NOT EXISTS `tbl_slider` (
  `sliderId` int(11) NOT NULL AUTO_INCREMENT,
  `sliderName` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `slider_image` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `type` int(11) NOT NULL,
  PRIMARY KEY (`sliderId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `tbl_warehouse`
--

DROP TABLE IF EXISTS `tbl_warehouse`;
CREATE TABLE IF NOT EXISTS `tbl_warehouse` (
  `id_warehouse` int(11) NOT NULL AUTO_INCREMENT,
  `id_sanpham` int(11) NOT NULL,
  `sl_nhap` varchar(50) NOT NULL,
  `sl_ngaynhap` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_warehouse`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `tbl_wishlist`
--

DROP TABLE IF EXISTS `tbl_wishlist`;
CREATE TABLE IF NOT EXISTS `tbl_wishlist` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `customer_id` int(11) NOT NULL,
  `productId` int(11) NOT NULL,
  `productName` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `price` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `image` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Đang đổ dữ liệu cho bảng `tbl_wishlist`
--

INSERT INTO `tbl_wishlist` (`id`, `customer_id`, `productId`, `productName`, `price`, `image`) VALUES
(4, 3, 18, 'Laptop Dell G7 7588 N7588A Core i7-8750H/Win10 (15.6 inch)', '2589900', '32942e9470.jpg'),
(5, 3, 15, 'Laptop Apple MacBook Air 2017 i5', '19390000', 'apple-macbook-air-mqd32sa-a-i5-5350u-bac-1-org.jpg');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
