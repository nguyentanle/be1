
<div class="slider-area">
    <!-- Slider -->
    <div class="block-slider block-slider4">
        <div class="bx-wrapper" style="max-width: 100%;"><div class="bx-viewport" style="width: 100%; overflow: hidden; position: relative; height: 93px;"><ul class="" id="bxslider-home4" style="width: 615%; position: relative; transition-duration: 0s; transform: translate3d(-931px, 0px, 0px);"><li style="float: left; list-style: none; position: relative; width: 297px;" class="bx-clone"><img src="img/h4-slide4.png" alt="Slide">
                <div class="caption-group">
                    <h2 class="caption title animated fadeInRight">
                        Apple <span class="primary">Store <strong>Ipod</strong></span>
                    </h2>
                    <h4 class="caption subtitle animated fadeInRight">&amp; Phone</h4>
                    <a class="caption button-radius animated fadeInRight" href="#"><span class="icon"></span>Shop now</a>
                </div>
            </li>
            <li style="float: left; list-style: none; position: relative; width: 297px;">
                <img src="admin/uploads/h4-slide.png" alt="Slide">
                <div class="caption-group">
                    <h2 class="caption title animated fadeInRight" style="display: block;">
                        iPhone <span class="primary">6 <strong>Plus</strong></span>
                    </h2>
                    <h4 class="caption subtitle animated fadeInRight" style="display: block;">Dual SIM</h4>
                    <a class="caption button-radius animated fadeInRight" href="#" style="display: inline-block;"><span class="icon"></span>Shop now</a>
                </div>
            </li>
            <li style="float: left; list-style: none; position: relative; width: 297px;"><img src="admin/uploads/h4-slide2.png" alt="Slide">
                <div class="caption-group">
                    <h2 class="caption title animated fadeInRight" style="display: block;">
                        by one, get one <span class="primary">50% <strong>off</strong></span>
                    </h2>
                    <h4 class="caption subtitle animated fadeInRight" style="display: block;">school supplies &amp; backpacks.*</h4>
                    <a class="caption button-radius animated fadeInRight" href="#" style="display: inline-block;"><span class="icon"></span>Shop now</a>
                </div>
            </li>
            <li style="float: left; list-style: none; position: relative; width: 297px;"><img src="admin/uploads/h4-slide3.png" alt="Slide">
                <div class="caption-group">
                    <h2 class="caption title animated fadeInRight" style="display: block;">
                        Apple <span class="primary">Store <strong>Ipod</strong></span>
                    </h2>
                    <h4 class="caption subtitle animated fadeInRight" style="display: block;">Select Item</h4>
                    <a class="caption button-radius animated fadeInRight" href="#" style="display: inline-block;"><span class="icon"></span>Shop now</a>
                </div>
            </li>
            <li style="float: left; list-style: none; position: relative; width: 297px;"><img src="admin/uploads/h4-slide4.png" alt="Slide">
                <div class="caption-group">
                    <h2 class="caption title animated fadeInRight" style="display: block;">
                        Apple <span class="primary">Store <strong>Ipod</strong></span>
                    </h2>
                    <h4 class="caption subtitle animated fadeInRight" style="display: block;">&amp; Phone</h4>
                    <a class="caption button-radius animated fadeInRight" href="#" style="display: inline-block;"><span class="icon"></span>Shop now</a>
                </div>
            </li>
        <li style="float: left; list-style: none; position: relative; width: 297px;" class="bx-clone">
                <img src="admin/uploads/h4-slide.png" alt="Slide">
                <div class="caption-group">
                    <h2 class="caption title animated fadeInRight">
                        iPhone <span class="primary">6 <strong>Plus</strong></span>
                    </h2>
                    <h4 class="caption subtitle animated fadeInRight">Dual SIM</h4>
                    <a class="caption button-radius animated fadeInRight" href="#"><span class="icon"></span>Shop now</a>
                </div>
            </li></ul></div><div class="bx-controls bx-has-pager bx-has-controls-direction"><div class="bx-pager bx-default-pager"><div class="bx-pager-item"><a href="" data-slide-index="0" class="bx-pager-link">1</a></div><div class="bx-pager-item"><a href="" data-slide-index="1" class="bx-pager-link">2</a></div><div class="bx-pager-item"><a href="" data-slide-index="2" class="bx-pager-link active">3</a></div><div class="bx-pager-item"><a href="" data-slide-index="3" class="bx-pager-link">4</a></div></div><div class="bx-controls-direction"><a class="bx-prev" href=""><i class="fa fa-angle-left"></i></a><a class="bx-next" href=""><i class="fa fa-angle-right"></i></a></div></div></div>
    </div>
    <!-- ./Slider -->
</div>
