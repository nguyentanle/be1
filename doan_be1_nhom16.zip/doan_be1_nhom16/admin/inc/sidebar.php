<div class="grid_2">
    <div class="box sidemenu">
        <div class="block" id="section-menu">
            <ul class="section menu">
                <li><a class="menuitem">Category</a>
                    <ul class="submenu">
                        <li><a href="catadd.php">Category add</a> </li>
                        <li><a href="catlist.php">Category list</a> </li>
                    </ul>
                </li>
                <li><a class="menuitem">Brand</a>
                    <ul class="submenu">
                        <li><a href="brandadd.php">Brand add</a> </li>
                        <li><a href="brandlist.php">Brand list</a> </li>
                    </ul>
                </li>
                <li><a class="menuitem">Product</a>
                    <ul class="submenu">
                        <li><a href="productadd.php">Product add</a> </li>
                        <li><a href="productlist.php">Product list</a> </li>
                    </ul>
                </li>
                 <li><a class="menuitem">Order</a>
                    <ul class="submenu">
                        <li><a href="inbox.php">Order list</a> </li>
                      
                    </ul>
                    <li><a class="menuitem">Slider</a>
                    <ul class="submenu">
                        <li><a href="slideradd.php">Slider add</a> </li>
                        <li><a href="sliderlist.php">Slider list</a> </li>
                    </ul>
                </li>
                </li>
                 
              
              
               
                
            </ul>
        </div>
    </div>
</div>