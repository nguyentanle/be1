<?php
//Name of database
define('DB_NAME', 'doan_be1_nhom16');
//MySQL username
define('DB_USER', 'root');
//MySQL password
define('DB_PASS', '');
//MySQL host
define('DB_HOST', 'localhost');